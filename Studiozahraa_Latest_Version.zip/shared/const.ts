export const COOKIE_NAME = "app_session_id";
export const ONE_YEAR_MS = 1000 * 60 * 60 * 24 * 365;

// Zahraa Studio - Shared Constants
export const STORE_NAME = "ZAHRAA STUDIO";
export const STORE_DESCRIPTION = "متجر فاخر للمنتجات والخدمات";

export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyCG6Yc0iH-rt-PaiRqL_V9Re1z49ZF3OMM",
  authDomain: "zahraa-store-f4c90.firebaseapp.com",
  projectId: "zahraa-store-f4c90",
};

export const CONTACT_INFO = {
  whatsapp1: "201204194540",
  whatsapp2: "201286815625",
  phone: "01286815625",
  facebook: "https://www.facebook.com/share/1DuEaxYhW3/",
};

export const COLORS = {
  primary: "#D4AF37",
  dark: "#0F0F0F",
  darkCard: "#1a1a1a",
  darkBg: "#0d0d0d",
  white: "#FFFFFF",
  lightGray: "#F5F5F5",
  gold: "#FFD700",
  darkGold: "#B8860B",
};

export const BREAKPOINTS = {
  mobile: 640,
  tablet: 1024,
  desktop: 1280,
};

export const GRID_COLUMNS = {
  mobile: 1,
  tablet: 2,
  desktop: 4,
};
