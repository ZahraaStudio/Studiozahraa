import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, ShoppingCart, Share2, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/useCart";
import type { Product } from "@/hooks/useProducts";

export default function ProductPage() {
  const [product, setProduct] = useState<Product | null>(null);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isAdded, setIsAdded] = useState(false);
  const { addToCart } = useCart();

  useEffect(() => {
    const savedProduct = localStorage.getItem("selectedProduct");
    if (savedProduct) {
      setProduct(JSON.parse(savedProduct));
    }
  }, []);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-4">⏳</div>
          <p className="text-foreground/70">جاري تحميل المنتج...</p>
        </div>
      </div>
    );
  }

  const images = product.images || [];
  const currentImage = images[currentImageIndex] || "";

  const handlePrevImage = () => {
    setCurrentImageIndex((prev) =>
      prev === 0 ? images.length - 1 : prev - 1
    );
  };

  const handleNextImage = () => {
    setCurrentImageIndex((prev) =>
      prev === images.length - 1 ? 0 : prev + 1
    );
  };

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.images?.[0],
      });
    }
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const handleShare = () => {
    const text = encodeURIComponent(
      `تحقق من هذا المنتج الرائع: ${product.name} - ${product.price} جنيه`
    );
    window.open(`https://wa.me/?text=${text}`, "_blank");
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container">
        {/* Back Button */}
        <button
          onClick={() => window.history.back()}
          className="mb-6 text-primary hover:text-primary/80 smooth-transition flex items-center gap-2"
        >
          ← العودة
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Image Section */}
          <div className="space-y-4">
            {/* Main Image */}
            <div className="relative w-full aspect-square bg-black/50 rounded-xl overflow-hidden luxury-card">
              {currentImage && (
                <img
                  src={currentImage}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              )}

              {/* Navigation Buttons */}
              {images.length > 1 && (
                <>
                  <button
                    onClick={handlePrevImage}
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-primary/80 hover:bg-primary text-black p-3 rounded-full smooth-transition z-10"
                  >
                    <ChevronRight size={24} />
                  </button>
                  <button
                    onClick={handleNextImage}
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-primary/80 hover:bg-primary text-black p-3 rounded-full smooth-transition z-10"
                  >
                    <ChevronLeft size={24} />
                  </button>
                </>
              )}
            </div>

            {/* Thumbnail Gallery */}
            {images.length > 1 && (
              <div className="flex gap-3 overflow-x-auto pb-2">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentImageIndex(idx)}
                    className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 smooth-transition ${
                      idx === currentImageIndex
                        ? "border-primary"
                        : "border-primary/30 hover:border-primary/60"
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info Section */}
          <div className="space-y-6">
            {/* Title and Price */}
            <div>
              <h1 className="text-4xl font-bold text-foreground mb-3">
                {product.name}
              </h1>
              <div className="flex items-baseline gap-3">
                <span className="text-4xl font-bold gradient-text">
                  {product.price} جنيه
                </span>
              </div>
            </div>

            {/* Description */}
            {product.description && (
              <div className="luxury-card">
                <h3 className="text-lg font-bold text-primary mb-3">الوصف</h3>
                <p className="text-foreground/80 leading-relaxed">
                  {product.description}
                </p>
              </div>
            )}

            {/* Quantity Selector */}
            <div className="luxury-card">
              <h3 className="text-lg font-bold text-primary mb-4">الكمية</h3>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-4 py-2 bg-primary/20 hover:bg-primary/30 rounded-lg smooth-transition text-foreground"
                >
                  −
                </button>
                <span className="text-2xl font-bold w-12 text-center">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-4 py-2 bg-primary/20 hover:bg-primary/30 rounded-lg smooth-transition text-foreground"
                >
                  +
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button
                onClick={handleAddToCart}
                className={`w-full bg-primary hover:bg-primary/90 text-black font-bold py-4 text-lg smooth-transition ${
                  isAdded ? "ring-2 ring-green-400" : ""
                }`}
              >
                <ShoppingCart size={20} className="ml-2" />
                {isAdded ? "تمت الإضافة للسلة" : "أضف للسلة"}
              </Button>

              <div className="grid grid-cols-2 gap-3">
                <Button
                  onClick={handleShare}
                  variant="outline"
                  className="border-primary/30 hover:bg-primary/10 font-bold py-3 smooth-transition"
                >
                  <Share2 size={18} className="ml-2" />
                  شارك
                </Button>
                <Button
                  onClick={() => setIsFavorite(!isFavorite)}
                  variant="outline"
                  className={`border-primary/30 hover:bg-primary/10 font-bold py-3 smooth-transition ${
                    isFavorite ? "bg-red-500/10 border-red-500/30" : ""
                  }`}
                >
                  <Heart
                    size={18}
                    className={`ml-2 ${isFavorite ? "fill-current" : ""}`}
                  />
                  {isFavorite ? "محفوظ" : "احفظ"}
                </Button>
              </div>

              <Button
                onClick={() => {
                  const text = encodeURIComponent(
                    `عايز المنتج: ${product.name} - السعر: ${product.price} جنيه - الكمية: ${quantity}`
                  );
                  window.open(`https://wa.me/201204194540?text=${text}`, "_blank");
                }}
                className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-4 text-lg smooth-transition"
              >
                واتساب
              </Button>
            </div>

            {/* Product Details */}
            <div className="luxury-card space-y-3">
              <h3 className="text-lg font-bold text-primary">معلومات المنتج</h3>
              <div className="space-y-2 text-sm text-foreground/70">
                <p>✓ منتج أصلي 100%</p>
                <p>✓ توصيل سريع وآمن</p>
                <p>✓ ضمان الجودة</p>
                <p>✓ خدمة عملاء متواصلة</p>
              </div>
            </div>
          </div>
        </div>

        {/* Related Products Section */}
        <div className="mt-16">
          <h2 className="text-3xl font-bold gradient-text mb-8">منتجات ذات صلة</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((idx) => (
              <div key={idx} className="luxury-card text-center">
                <div className="w-full aspect-square bg-black/50 rounded-lg mb-3 flex items-center justify-center">
                  <span className="text-4xl">🛍️</span>
                </div>
                <h3 className="font-bold text-primary mb-2">منتج مشابه {idx}</h3>
                <p className="text-foreground/70 text-sm">اكتشف منتجات أخرى مشابهة</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
