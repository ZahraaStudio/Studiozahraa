import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ShoppingBag, Zap, Award, Heart } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent" />
        <div className="container relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-6">
              <div className="space-y-2">
                <h1 className="text-5xl md:text-6xl font-bold leading-tight">
                  <span className="gradient-text">ZAHRAA</span>
                  <br />
                  <span className="text-foreground">STUDIO</span>
                </h1>
              </div>
              <p className="text-xl text-foreground/70 leading-relaxed">
                متجر فاخر يقدم أرقى المنتجات والخدمات المختارة بعناية لتلبية أذواقك الراقية.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link href="/products">
                  <Button className="bg-primary hover:bg-primary/90 text-black font-bold py-6 px-8 text-lg smooth-transition">
                    <ShoppingBag className="ml-2" />
                    تصفح المتجر
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  className="border-primary/30 hover:bg-primary/10 font-bold py-6 px-8 text-lg smooth-transition"
                  onClick={() =>
                    window.open(
                      "https://wa.me/201204194540?text=مرحبا، أود الاستفسار عن المنتجات",
                      "_blank"
                    )
                  }
                >
                  تواصل معنا
                </Button>
              </div>
            </div>

            {/* Right Visual */}
            <div className="relative h-96 md:h-full">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-primary/10 rounded-2xl" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-8xl animate-float">✨</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24 bg-card/30">
        <div className="container">
          <h2 className="text-4xl font-bold gradient-text mb-12 text-center">
            لماذا تختار ZAHRAA STUDIO؟
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Award,
                title: "جودة عالية",
                description: "منتجات مختارة بعناية",
              },
              {
                icon: Zap,
                title: "سرعة التوصيل",
                description: "توصيل سريع وآمن",
              },
              {
                icon: Heart,
                title: "خدمة عملاء",
                description: "دعم متواصل 24/7",
              },
              {
                icon: ShoppingBag,
                title: "أسعار منافسة",
                description: "أفضل الأسعار في السوق",
              },
            ].map((feature, idx) => (
              <div key={idx} className="luxury-card text-center space-y-3">
                <div className="flex justify-center">
                  <feature.icon className="w-12 h-12 text-primary" />
                </div>
                <h3 className="text-lg font-bold text-foreground">
                  {feature.title}
                </h3>
                <p className="text-foreground/60 text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="luxury-card text-center py-12 space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold gradient-text">
              هل أنت مستعد للتسوق؟
            </h2>
            <p className="text-foreground/70 text-lg max-w-2xl mx-auto">
              اكتشف مجموعتنا الفاخرة من المنتجات المختارة بعناية
            </p>
            <Link href="/products">
              <Button className="bg-primary hover:bg-primary/90 text-black font-bold py-6 px-8 text-lg smooth-transition">
                ابدأ التسوق الآن
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 md:py-24 bg-card/30">
        <div className="container">
          <h2 className="text-3xl font-bold gradient-text mb-8 text-center">
            تواصل معنا
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-2xl mx-auto">
            <a
              href="https://wa.me/201204194540"
              target="_blank"
              rel="noopener noreferrer"
              className="luxury-card text-center py-8 hover:scale-105 transition-transform"
            >
              <div className="text-4xl mb-3">💬</div>
              <h3 className="font-bold text-foreground mb-2">واتساب</h3>
              <p className="text-primary text-sm">+20 120 419 4540</p>
            </a>
            <a
              href="tel:01286815625"
              className="luxury-card text-center py-8 hover:scale-105 transition-transform"
            >
              <div className="text-4xl mb-3">📞</div>
              <h3 className="font-bold text-foreground mb-2">اتصل بنا</h3>
              <p className="text-primary text-sm">+20 128 681 5625</p>
            </a>
            <a
              href="https://www.facebook.com/share/1DuEaxYhW3/"
              target="_blank"
              rel="noopener noreferrer"
              className="luxury-card text-center py-8 hover:scale-105 transition-transform"
            >
              <div className="text-4xl mb-3">👍</div>
              <h3 className="font-bold text-foreground mb-2">فيسبوك</h3>
              <p className="text-primary text-sm">تابعنا</p>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
