import { useState, useEffect } from "react";
import { Plus, Edit2, Trash2, Upload, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface Product {
  id: string;
  name: string;
  price: number;
  description?: string;
  images: string[];
}

export default function Admin() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [products, setProducts] = useState<Product[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    description: "",
    images: [] as string[],
  });
  const [imageUrl, setImageUrl] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      // Load Firebase scripts
      const script1 = document.createElement("script");
      script1.src = "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
      script1.async = true;

      script1.onload = () => {
        const script2 = document.createElement("script");
        script2.src = "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
        script2.async = true;

        script2.onload = () => {
          const script3 = document.createElement("script");
          script3.src = "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
          script3.async = true;

          script3.onload = () => {
            initializeFirebase();
          };

          document.head.appendChild(script3);
        };

        document.head.appendChild(script2);
      };

      document.head.appendChild(script1);
    } catch (error) {
      console.error("Failed to load Firebase:", error);
      setIsLoading(false);
    }
  };

  const initializeFirebase = async () => {
    try {
      // @ts-ignore
      const { initializeApp } = window.firebase;
      // @ts-ignore
      const { getAuth, onAuthStateChanged } = window.firebase.auth;

      const firebaseConfig = {
        apiKey: "AIzaSyCG6Yc0iH-rt-PaiRqL_V9Re1z49ZF3OMM",
        authDomain: "zahraa-store-f4c90.firebaseapp.com",
        projectId: "zahraa-store-f4c90",
      };

      const app = initializeApp(firebaseConfig);
      const auth = getAuth(app);

      onAuthStateChanged(auth, (user: any) => {
        if (user) {
          setIsLoggedIn(true);
          loadProducts();
        } else {
          setIsLoggedIn(false);
        }
        setIsLoading(false);
      });
    } catch (error) {
      console.error("Firebase initialization failed:", error);
      setIsLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");

    try {
      // @ts-ignore
      const { signInWithEmailAndPassword } = (window as any).firebase.auth;
      // @ts-ignore
      const { getAuth } = (window as any).firebase.auth;

      const auth = getAuth();
      await signInWithEmailAndPassword(auth, email, password);
      setEmail("");
      setPassword("");
    } catch (error: any) {
      console.error("Login failed:", error);
      setLoginError("فشل تسجيل الدخول. تحقق من البيانات.");
    }
  };

  const loadProducts = async () => {
    try {
      // @ts-ignore
      const { getFirestore, collection, getDocs } = (window as any).firebase.firestore;
      // @ts-ignore
      const { getAuth } = (window as any).firebase.auth;

      const auth = getAuth();
      if (!auth.currentUser) return;

      const db = getFirestore();
      const querySnapshot = await getDocs(collection(db, "products"));
      const loadedProducts: Product[] = [];

      querySnapshot.forEach((doc: any) => {
        loadedProducts.push({
          id: doc.id,
          ...doc.data(),
        } as Product);
      });

      setProducts(loadedProducts);
    } catch (error) {
      console.error("Failed to load products:", error);
    }
  };

  const handleAddImage = () => {
    if (imageUrl.trim()) {
      setFormData({
        ...formData,
        images: [...formData.images, imageUrl],
      });
      setImageUrl("");
    }
  };

  const handleRemoveImage = (index: number) => {
    setFormData({
      ...formData,
      images: formData.images.filter((_, i) => i !== index),
    });
  };

  const handleSave = async () => {
    if (!formData.name || !formData.price) {
      alert("الرجاء ملء جميع الحقول المطلوبة");
      return;
    }

    try {
      // @ts-ignore
      const { getFirestore, collection, addDoc, updateDoc, doc } =
        (window as any).firebase.firestore;
      // @ts-ignore
      const { getAuth } = (window as any).firebase.auth;

      const auth = getAuth();
      if (!auth.currentUser) {
        alert("يجب تسجيل الدخول أولاً");
        return;
      }

      const db = getFirestore();

      const productData = {
        name: formData.name,
        price: parseFloat(formData.price),
        description: formData.description,
        images: formData.images,
        updatedAt: new Date().getTime(),
      };

      if (editingId) {
        await updateDoc(doc(db, "products", editingId), productData);
        alert("تم تحديث المنتج بنجاح");
      } else {
        await addDoc(collection(db, "products"), productData);
        alert("تم إضافة المنتج بنجاح");
      }

      setFormData({
        name: "",
        price: "",
        description: "",
        images: [],
      });
      setEditingId(null);
      loadProducts();
    } catch (error) {
      console.error("Failed to save product:", error);
      alert("فشل حفظ المنتج");
    }
  };

  const handleEdit = (product: Product) => {
    setFormData({
      name: product.name,
      price: product.price.toString(),
      description: product.description || "",
      images: product.images || [],
    });
    setEditingId(product.id);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذا المنتج؟")) return;

    try {
      // @ts-ignore
      const { getFirestore, deleteDoc, doc } = (window as any).firebase.firestore;
      // @ts-ignore
      const { getAuth } = (window as any).firebase.auth;

      const auth = getAuth();
      if (!auth.currentUser) {
        alert("يجب تسجيل الدخول أولاً");
        return;
      }

      const db = getFirestore();
      await deleteDoc(doc(db, "products", id));
      alert("تم حذف المنتج بنجاح");
      loadProducts();
    } catch (error) {
      console.error("Failed to delete product:", error);
      alert("فشل حذف المنتج");
    }
  };

  const handleLogout = async () => {
    try {
      // @ts-ignore
      const { getAuth, signOut } = window.firebase.auth;
      const auth = getAuth();
      await signOut(auth);
      setIsLoggedIn(false);
      setProducts([]);
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin text-4xl mb-4">⏳</div>
          <p className="text-foreground/70">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="luxury-card max-w-md w-full py-12 px-8">
          <div className="text-4xl mb-4 text-center">🔐</div>
          <h1 className="text-2xl font-bold gradient-text mb-2 text-center">
            لوحة التحكم
          </h1>
          <p className="text-foreground/70 mb-8 text-center text-sm">
            تسجيل الدخول للوصول إلى إدارة المنتجات
          </p>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-foreground/70 text-sm block mb-2">
                البريد الإلكتروني
              </label>
              <Input
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-black/30 border-primary/30 text-foreground"
              />
            </div>

            <div>
              <label className="text-foreground/70 text-sm block mb-2">
                كلمة المرور
              </label>
              <Input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-black/30 border-primary/30 text-foreground"
              />
            </div>

            {loginError && (
              <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
                <p className="text-red-400 text-sm">{loginError}</p>
              </div>
            )}

            <Button
              type="submit"
              className="w-full bg-primary hover:bg-primary/90 text-black font-bold py-3"
            >
              تسجيل الدخول
            </Button>
          </form>

          <div className="mt-6 pt-6 border-t border-primary/20">
            <p className="text-foreground/50 text-xs text-center">
              استخدم بيانات Firebase الخاصة بك للدخول
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold gradient-text">لوحة التحكم</h1>
          <Button
            onClick={handleLogout}
            className="bg-red-500 hover:bg-red-600 text-white font-bold"
          >
            <LogOut size={18} className="ml-2" />
            تسجيل الخروج
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form Section */}
          <div className="lg:col-span-1">
            <div className="luxury-card space-y-4 sticky top-24">
              <h2 className="text-2xl font-bold text-primary">
                {editingId ? "تعديل المنتج" : "إضافة منتج جديد"}
              </h2>

              <div className="space-y-3">
                <div>
                  <label className="text-foreground/70 text-sm block mb-2">
                    اسم المنتج
                  </label>
                  <Input
                    type="text"
                    placeholder="اسم المنتج"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    className="bg-black/30 border-primary/30"
                  />
                </div>

                <div>
                  <label className="text-foreground/70 text-sm block mb-2">
                    السعر (جنيه)
                  </label>
                  <Input
                    type="number"
                    placeholder="السعر"
                    value={formData.price}
                    onChange={(e) =>
                      setFormData({ ...formData, price: e.target.value })
                    }
                    className="bg-black/30 border-primary/30"
                  />
                </div>

                <div>
                  <label className="text-foreground/70 text-sm block mb-2">
                    الوصف
                  </label>
                  <textarea
                    placeholder="وصف المنتج"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    className="w-full bg-black/30 border border-primary/30 rounded-lg p-3 text-foreground placeholder:text-foreground/50 resize-none"
                    rows={3}
                  />
                </div>

                {/* Images */}
                <div>
                  <label className="text-foreground/70 text-sm block mb-2">
                    الصور
                  </label>
                  <div className="flex gap-2 mb-3">
                    <Input
                      type="url"
                      placeholder="رابط الصورة"
                      value={imageUrl}
                      onChange={(e) => setImageUrl(e.target.value)}
                      className="flex-1 bg-black/30 border-primary/30"
                    />
                    <Button
                      onClick={handleAddImage}
                      className="bg-primary/20 hover:bg-primary/30 text-primary font-bold"
                    >
                      <Upload size={18} />
                    </Button>
                  </div>

                  {/* Image Preview */}
                  {formData.images.length > 0 && (
                    <div className="grid grid-cols-2 gap-2 mb-3">
                      {formData.images.map((img, idx) => (
                        <div key={idx} className="relative group">
                          <img
                            src={img}
                            alt={`Product ${idx}`}
                            className="w-full h-20 object-cover rounded-lg"
                          />
                          <button
                            onClick={() => handleRemoveImage(idx)}
                            className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-lg"
                          >
                            <Trash2 size={18} className="text-red-400" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex gap-2 pt-4">
                  <Button
                    onClick={handleSave}
                    className="flex-1 bg-primary hover:bg-primary/90 text-black font-bold py-3"
                  >
                    <Plus size={18} className="ml-2" />
                    {editingId ? "تحديث" : "إضافة"}
                  </Button>
                  {editingId && (
                    <Button
                      onClick={() => {
                        setEditingId(null);
                        setFormData({
                          name: "",
                          price: "",
                          description: "",
                          images: [],
                        });
                      }}
                      variant="outline"
                      className="flex-1 border-primary/30 font-bold"
                    >
                      إلغاء
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Products List */}
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold text-primary mb-4">
              المنتجات ({products.length})
            </h2>
            <div className="space-y-3">
              {products.length === 0 ? (
                <div className="luxury-card text-center py-8">
                  <p className="text-foreground/70">لا توجد منتجات حتى الآن</p>
                </div>
              ) : (
                products.map((product) => (
                  <div
                    key={product.id}
                    className="luxury-card flex gap-4 items-start hover:bg-white/15 transition-colors"
                  >
                    {product.images?.[0] && (
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        className="w-20 h-20 object-cover rounded-lg flex-shrink-0"
                      />
                    )}
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-lg">
                        {product.name}
                      </h3>
                      <p className="text-primary font-bold mb-1">
                        {product.price} جنيه
                      </p>
                      {product.description && (
                        <p className="text-foreground/60 text-sm line-clamp-2">
                          {product.description}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2 flex-shrink-0">
                      <Button
                        onClick={() => handleEdit(product)}
                        size="sm"
                        className="bg-blue-500/20 hover:bg-blue-500/30 text-blue-400"
                      >
                        <Edit2 size={16} />
                      </Button>
                      <Button
                        onClick={() => handleDelete(product.id)}
                        size="sm"
                        className="bg-red-500/20 hover:bg-red-500/30 text-red-400"
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
