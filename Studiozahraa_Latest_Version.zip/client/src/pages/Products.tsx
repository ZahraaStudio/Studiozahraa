import { useState, useMemo } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import ProductCard from "@/components/ProductCard";
import { useProducts, type Product } from "@/hooks/useProducts";
import { useCart } from "@/hooks/useCart";

export default function Products() {
  const { products, isLoading, error } = useProducts();
  const { addToCart } = useCart();
  const [searchQuery, setSearchQuery] = useState("");

  const filteredProducts = useMemo(() => {
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [products, searchQuery]);

  const handleAddToCart = (product: Product) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images?.[0],
    });
  };

  const handleOpenProduct = (product: Product) => {
    localStorage.setItem("selectedProduct", JSON.stringify(product));
    window.location.href = "/product";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-primary/10 to-transparent py-12">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-4">
            🔥 المنتجات المميزة
          </h1>
          <p className="text-foreground/70 text-lg">
            اكتشف مجموعتنا الفاخرة من المنتجات الحصرية
          </p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="sticky top-20 z-30 bg-card/50 backdrop-blur-sm border-b border-primary/20 py-4">
        <div className="container">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-primary/50" />
            <Input
              type="text"
              placeholder="ابحث عن منتج..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-4 pr-10 bg-black/30 border-primary/30 text-foreground placeholder:text-foreground/50"
            />
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="container py-12">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <div className="animate-spin text-4xl mb-4">⏳</div>
              <p className="text-foreground/70">جاري تحميل المنتجات...</p>
            </div>
          </div>
        ) : error ? (
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <div className="text-4xl mb-4">⚠️</div>
              <p className="text-red-400">{error}</p>
            </div>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <div className="text-4xl mb-4">🔍</div>
              <p className="text-foreground/70">لم نجد منتجات مطابقة</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={handleAddToCart}
                onOpenProduct={handleOpenProduct}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
