import { useState, useEffect } from "react";

export interface Product {
  id: string;
  name: string;
  price: number;
  description?: string;
  images: string[];
  category?: string;
  createdAt?: number;
}

export function useProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Use dynamic script loading for Firebase
      const script = document.createElement("script");
      script.src =
        "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
      script.async = true;

      script.onload = async () => {
        const script2 = document.createElement("script");
        script2.src =
          "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
        script2.async = true;

        script2.onload = async () => {
          try {
            // @ts-ignore - Firebase global
            const { initializeApp } = window.firebase;
            // @ts-ignore - Firebase global
            const { getFirestore, collection, getDocs } = window.firebase.firestore;

            const FIREBASE_CONFIG = {
              apiKey: "AIzaSyCG6Yc0iH-rt-PaiRqL_V9Re1z49ZF3OMM",
              authDomain: "zahraa-store-f4c90.firebaseapp.com",
              projectId: "zahraa-store-f4c90",
            };

            const app = initializeApp(FIREBASE_CONFIG);
            const db = getFirestore(app);

            const querySnapshot = await getDocs(
              collection(db, "products")
            );
            const loadedProducts: Product[] = [];

            querySnapshot.forEach((doc: any) => {
              loadedProducts.push({
                id: doc.id,
                ...doc.data(),
              } as Product);
            });

            setProducts(loadedProducts);
          } catch (err) {
            console.error("Failed to load products:", err);
            setError("فشل تحميل المنتجات");
          } finally {
            setIsLoading(false);
          }
        };

        document.head.appendChild(script2);
      };

      document.head.appendChild(script);
    } catch (err) {
      console.error("Failed to load Firebase:", err);
      setError("فشل تحميل المنتجات");
      setIsLoading(false);
    }
  };

  const getProductById = (id: string): Product | undefined => {
    return products.find((p) => p.id === id);
  };

  const searchProducts = (query: string): Product[] => {
    const lowerQuery = query.toLowerCase();
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(lowerQuery) ||
        p.description?.toLowerCase().includes(lowerQuery)
    );
  };

  return {
    products,
    isLoading,
    error,
    getProductById,
    searchProducts,
    refetch: loadProducts,
  };
}
