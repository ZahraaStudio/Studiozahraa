import { useState } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Products from "./pages/Products";
import Product from "./pages/Product";
import Admin from "./pages/Admin";
import Header from "./components/Header";
import CartSidebar from "./components/CartSidebar";
import { useCart } from "./hooks/useCart";
import { Phone, MessageCircle } from "lucide-react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/products" component={Products} />
      <Route path="/product" component={Product} />
      <Route path="/admin" component={Admin} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { cart, getTotalPrice, getTotalItems, updateQuantity, removeFromCart, clearCart } = useCart();

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <div className="flex flex-col min-h-screen">
            <Header 
              cartCount={getTotalItems()} 
              onCartClick={() => setIsCartOpen(true)} 
            />
            <main className="flex-1">
              <Router />
            </main>
            <CartSidebar
              isOpen={isCartOpen}
              onClose={() => setIsCartOpen(false)}
              cartItems={cart}
              totalPrice={getTotalPrice()}
              onUpdateQuantity={updateQuantity}
              onRemoveItem={removeFromCart}
              onCheckout={() => {
                const text = encodeURIComponent(
                  `طلب جديد:\n${cart.map(item => `${item.name} x${item.quantity} - ${item.price * item.quantity} جنيه`).join('\n')}\n\nالإجمالي: ${getTotalPrice()} جنيه`
                );
                window.open(`https://wa.me/201204194540?text=${text}`, "_blank");
                clearCart();
                setIsCartOpen(false);
              }}
            />
            
            {/* Floating Action Buttons */}
            <div className="fixed bottom-6 right-6 flex flex-col gap-4 z-50">
              <a
                href="tel:01286815625"
                className="w-14 h-14 rounded-full bg-blue-500 flex items-center justify-center text-white shadow-lg hover:scale-110 transition-transform"
                title="اتصل بنا"
              >
                <Phone size={28} />
              </a>
              <a
                href="https://wa.me/201204194540"
                target="_blank"
                rel="noopener noreferrer"
                className="w-14 h-14 rounded-full bg-green-500 flex items-center justify-center text-white shadow-lg hover:scale-110 transition-transform"
                title="واتساب"
              >
                <MessageCircle size={28} />
              </a>
            </div>
          </div>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
