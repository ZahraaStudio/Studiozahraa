import { X, Trash2, Plus, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { CartItem } from "@/hooks/useCart";

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  totalPrice: number;
  onUpdateQuantity: (itemId: string, quantity: number) => void;
  onRemoveItem: (itemId: string) => void;
  onCheckout: () => void;
}

export default function CartSidebar({
  isOpen,
  onClose,
  cartItems,
  totalPrice,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}: CartSidebarProps) {
  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 transition-opacity duration-300"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div
        className={`fixed top-0 right-0 h-full w-full max-w-md bg-card border-l border-primary/30 shadow-2xl transform transition-transform duration-300 z-50 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-primary/20">
          <h2 className="text-2xl font-bold gradient-text">السلة</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-primary/10 rounded-lg smooth-transition"
          >
            <X size={24} className="text-foreground" />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cartItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <div className="text-4xl mb-2">🛒</div>
              <p className="text-foreground/70">السلة فارغة</p>
              <p className="text-foreground/50 text-sm mt-1">
                أضف منتجات لبدء التسوق
              </p>
            </div>
          ) : (
            cartItems.map((item) => (
              <div
                key={item.id}
                className="glass p-3 rounded-lg flex gap-3 hover:bg-white/15 transition-colors"
              >
                {item.image && (
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-16 object-cover rounded-lg"
                  />
                )}
                <div className="flex-1">
                  <h3 className="font-bold text-foreground text-sm line-clamp-2">
                    {item.name}
                  </h3>
                  <p className="text-primary font-bold text-sm mt-1">
                    {item.price} جنيه
                  </p>
                  <div className="flex items-center gap-2 mt-2">
                    <button
                      onClick={() =>
                        onUpdateQuantity(item.id, item.quantity - 1)
                      }
                      className="p-1 hover:bg-primary/20 rounded smooth-transition"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="text-sm font-bold w-6 text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() =>
                        onUpdateQuantity(item.id, item.quantity + 1)
                      }
                      className="p-1 hover:bg-primary/20 rounded smooth-transition"
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                </div>
                <button
                  onClick={() => onRemoveItem(item.id)}
                  className="p-2 hover:bg-red-500/20 rounded smooth-transition"
                >
                  <Trash2 size={16} className="text-red-400" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {cartItems.length > 0 && (
          <div className="border-t border-primary/20 p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-foreground/70">الإجمالي:</span>
              <span className="text-2xl font-bold gradient-text">
                {totalPrice} جنيه
              </span>
            </div>
            <Button
              onClick={onCheckout}
              className="w-full bg-primary hover:bg-primary/90 text-black font-bold py-3 smooth-transition"
            >
              متابعة الشراء
            </Button>
          </div>
        )}
      </div>
    </>
  );
}
