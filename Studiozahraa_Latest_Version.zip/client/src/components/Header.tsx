import { ShoppingCart, Menu, X } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

interface HeaderProps {
  cartCount: number;
  onCartClick: () => void;
}

export default function Header({ cartCount, onCartClick }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 glass gold-border">
      <div className="container flex items-center justify-between py-4">
        {/* Logo */}
        <Link href="/">
          <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <img src="https://i.ibb.co/gFbYCVhy/file-000000003d48620a9a545c81b8bf35e5.png" alt="ZAHRAA STUDIO Logo" className="h-10 w-auto" />
            <div className="flex flex-col">
              <div className="text-xl font-bold gradient-text leading-none">ZAHRAA</div>
              <div className="text-[10px] text-foreground/60 leading-none">STUDIO</div>
            </div>
          </a>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <Link href="/">
            <a className="text-foreground hover:text-primary smooth-transition">
              الرئيسية
            </a>
          </Link>
          <Link href="/products">
            <a className="text-foreground hover:text-primary smooth-transition">
              المتجر
            </a>
          </Link>
          <Link href="/admin">
            <a className="text-foreground hover:text-primary smooth-transition">
              الإدارة
            </a>
          </Link>
          <a href="tel:01286815625" className="text-foreground hover:text-primary smooth-transition">
            اتصل بنا
          </a>
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          <button
            onClick={onCartClick}
            className="relative p-2 hover:bg-primary/10 rounded-lg smooth-transition group"
          >
            <ShoppingCart size={24} className="text-primary group-hover:scale-110 transition-transform" />
            {cartCount > 0 && (
              <span className="absolute top-0 right-0 bg-red-500 text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center animate-pulse">
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile Menu */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 hover:bg-primary/10 rounded-lg smooth-transition"
          >
            {isMenuOpen ? (
              <X size={24} className="text-foreground" />
            ) : (
              <Menu size={24} className="text-foreground" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden border-t border-primary/20 bg-card/50 backdrop-blur-sm">
          <nav className="container py-4 space-y-3">
            <Link href="/">
              <a
                className="block text-foreground hover:text-primary smooth-transition py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                الرئيسية
              </a>
            </Link>
            <Link href="/products">
              <a
                className="block text-foreground hover:text-primary smooth-transition py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                المتجر
              </a>
            </Link>
            <Link href="/admin">
              <a
                className="block text-foreground hover:text-primary smooth-transition py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                الإدارة
              </a>
            </Link>
            <a
              href="tel:01286815625"
              className="block text-foreground hover:text-primary smooth-transition py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              اتصل بنا
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
