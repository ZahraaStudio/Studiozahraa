import { useState } from "react";
import { ShoppingCart, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Product } from "@/hooks/useProducts";

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onOpenProduct: (product: Product) => void;
}

export default function ProductCard({
  product,
  onAddToCart,
  onOpenProduct,
}: ProductCardProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isAdded, setIsAdded] = useState(false);

  const images = product.images || [];
  const currentImage = images[currentImageIndex] || "";

  const handlePrevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImageIndex((prev) =>
      prev === 0 ? images.length - 1 : prev - 1
    );
  };

  const handleNextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImageIndex((prev) =>
      prev === images.length - 1 ? 0 : prev + 1
    );
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div
      className="luxury-card overflow-hidden cursor-pointer transform hover:scale-105 transition-transform duration-300"
      onClick={() => onOpenProduct(product)}
    >
      {/* Image Slider */}
      <div className="relative w-full aspect-square bg-black/50 overflow-hidden">
        {currentImage && (
          <img
            src={currentImage}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        )}

        {/* Image Navigation */}
        {images.length > 1 && (
          <>
            <button
              onClick={handlePrevImage}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-primary/80 hover:bg-primary text-black p-2 rounded-full smooth-transition z-10"
            >
              <ChevronRight size={16} />
            </button>
            <button
              onClick={handleNextImage}
              className="absolute left-2 top-1/2 -translate-y-1/2 bg-primary/80 hover:bg-primary text-black p-2 rounded-full smooth-transition z-10"
            >
              <ChevronLeft size={16} />
            </button>

            {/* Dots */}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1 z-10">
              {images.map((_, idx) => (
                <div
                  key={idx}
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    idx === currentImageIndex
                      ? "w-4 bg-primary"
                      : "w-1.5 bg-white/30"
                  }`}
                />
              ))}
            </div>
          </>
        )}
      </div>

      {/* Product Info */}
      <div className="p-4 space-y-3">
        <div>
          <h3 className="text-primary font-bold text-lg line-clamp-2">
            {product.name}
          </h3>
          {product.description && (
            <p className="text-foreground/70 text-sm mt-1 line-clamp-2">
              {product.description}
            </p>
          )}
        </div>

        {/* Price */}
        <div className="text-2xl font-bold gradient-text">
          {product.price} جنيه
        </div>

        {/* Buttons */}
        <div className="flex gap-2 pt-2">
          <Button
            onClick={handleAddToCart}
            className={`flex-1 bg-primary hover:bg-primary/90 text-black font-bold smooth-transition ${
              isAdded ? "ring-2 ring-green-400" : ""
            }`}
          >
            <ShoppingCart size={16} className="ml-2" />
            {isAdded ? "تمت الإضافة" : "أضف للسلة"}
          </Button>
          <Button
            onClick={(e) => {
              e.stopPropagation();
              const text = encodeURIComponent(
                `عايز المنتج: ${product.name} - السعر: ${product.price} جنيه`
              );
              window.open(`https://wa.me/201204194540?text=${text}`, "_blank");
            }}
            className="flex-1 bg-green-500 hover:bg-green-600 text-white font-bold smooth-transition"
          >
            واتساب
          </Button>
        </div>
      </div>
    </div>
  );
}
